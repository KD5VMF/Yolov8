import os
import shutil
import pickle

ENCODINGS_FILE = "encodings.pickle"
FACE_DIR = "faces"

def rename_subject(old_name, new_name):
    old_path = os.path.join(FACE_DIR, old_name)
    new_path = os.path.join(FACE_DIR, new_name)

    if not os.path.exists(old_path):
        print(f"Error: '{old_name}' not found in {FACE_DIR}.")
        return

    os.makedirs(new_path, exist_ok=True)

    # Move image files
    image_files = [f for f in os.listdir(old_path) if f.endswith(".jpg")]
    start_index = len(os.listdir(new_path))
    for i, file in enumerate(sorted(image_files)):
        old_file = os.path.join(old_path, file)
        new_file = os.path.join(new_path, f"{start_index + i}.jpg")
        shutil.move(old_file, new_file)
        print(f"Moved: {old_file} → {new_file}")

    if not os.listdir(old_path):
        os.rmdir(old_path)

    if os.path.exists(ENCODINGS_FILE):
        with open(ENCODINGS_FILE, "rb") as f:
            data = pickle.load(f)

        updated = False
        for i in range(len(data["names"])):
            if data["names"][i] == old_name:
                data["names"][i] = new_name
                updated = True

        if updated:
            with open(ENCODINGS_FILE, "wb") as f:
                pickle.dump(data, f)
            print(f"Updated pickle with new name '{new_name}'")

def list_subjects():
    subjects = [d for d in os.listdir(FACE_DIR) if os.path.isdir(os.path.join(FACE_DIR, d))]
    print("Subjects:")
    for i, s in enumerate(subjects):
        print(f"{i + 1}: {s}")
    return subjects

if __name__ == "__main__":
    print("Subject Renamer & Encoding Updater")
    print("==================================")

    subjects = list_subjects()
    if not subjects:
        print("No subjects found to rename.")
        exit()

    try:
        choice = int(input("Select subject number to rename: ")) - 1
        old = subjects[choice]
    except (ValueError, IndexError):
        print("Invalid selection.")
        exit()

    new = input(f"Enter new name for '{old}': ").strip()
    if not new:
        print("New name cannot be empty.")
        exit()

    rename_subject(old, new)
