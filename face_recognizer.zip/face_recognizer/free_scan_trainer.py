import cv2
import os
import face_recognition
import pickle
import numpy as np
import time

ENCODINGS_FILE = "encodings.pickle"
FACE_DIR = "faces"
os.makedirs(FACE_DIR, exist_ok=True)

def is_blurry(image, threshold=100.0):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    fm = cv2.Laplacian(gray, cv2.CV_64F).var()
    return fm < threshold, fm

def load_encodings():
    if os.path.exists(ENCODINGS_FILE):
        with open(ENCODINGS_FILE, "rb") as f:
            return pickle.load(f)
    return {"encodings": [], "names": []}

def save_encodings(data):
    with open(ENCODINGS_FILE, "wb") as f:
        pickle.dump(data, f)

def free_scan_train():
    print("Free Scan Training: Press 'q' to stop. Will auto-save sharp faces.")
    data = load_encodings()
    cap = cv2.VideoCapture(0)
    unknown_id = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        boxes = face_recognition.face_locations(rgb)
        encs = face_recognition.face_encodings(rgb, boxes)

        for (top, right, bottom, left), enc in zip(boxes, encs):
            face_img = frame[top:bottom, left:right]
            blurry, score = is_blurry(face_img)
            if blurry:
                continue

            matches = face_recognition.compare_faces(data["encodings"], enc)
            name = "unknown"
            if True in matches:
                idxs = [i for i, matched in enumerate(matches) if matched]
                names_found = [data["names"][i] for i in idxs]
                name = max(set(names_found), key=names_found.count)

            if name == "unknown":
                name = f"unknown_{unknown_id}"
                unknown_id += 1

            person_dir = os.path.join(FACE_DIR, name)
            os.makedirs(person_dir, exist_ok=True)
            files = [f for f in os.listdir(person_dir) if f.endswith(".jpg")]
            file_id = len(files)
            filename = f"{file_id}.jpg"
            save_path = os.path.join(person_dir, filename)
            cv2.imwrite(save_path, face_img)
            print(f"[{name}] sharp face saved -> {filename}")

            data["encodings"].append(enc)
            data["names"].append(name)

            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

        cv2.imshow("Free Scan Training - Press 'q' to quit", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    save_encodings(data)
    print("Session complete. Encodings updated.")

def review_and_rename_unknowns():
    folders = [d for d in os.listdir(FACE_DIR) if d.startswith("unknown_")]
    for folder in folders:
        print(f"Reviewing: {folder}")
        full_path = os.path.join(FACE_DIR, folder)
        images = sorted([f for f in os.listdir(full_path) if f.endswith(".jpg")])
        for img_file in images:
            img_path = os.path.join(full_path, img_file)
            img = cv2.imread(img_path)
            cv2.imshow("Unknown Face", img)
            print(f"Reviewing: {img_file} in {folder}")
            newname = input("Enter new name (or ENTER to skip): ").strip()
            if newname:
                newdir = os.path.join(FACE_DIR, newname)
                os.makedirs(newdir, exist_ok=True)
                count = len(os.listdir(newdir))
                new_path = os.path.join(newdir, f"{count}.jpg")
                os.rename(img_path, new_path)
                print(f"Moved to: {new_path}")
        if not os.listdir(full_path):
            os.rmdir(full_path)
        cv2.destroyAllWindows()

if __name__ == "__main__":
    print("Free Scan Trainer")
    print("=================")
    print("1: Start Free Scan Training")
    print("2: Review and Rename Unknowns")
    print("q: Quit")
    mode = input("Select an option: ").strip().lower()

    if mode == "1":
        free_scan_train()
    elif mode == "2":
        review_and_rename_unknowns()
    else:
        print("Exiting.")
