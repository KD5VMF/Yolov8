print("Face Recognition Suite")
print("======================")
print("1. Run Trainer (CLI)")
print("2. Run Recognizer (CLI)")
print("3. Reset All Data")
print("4. Run GUI App")
print("5. Free Scan Trainer")
print("6. Rename Subject and Update Encodings")
print("q. Quit")

choice = input("Select an option: ").strip()

if choice == "1":
    import subprocess
    subprocess.run(["python", "face_recognizer/trainer.py"])
elif choice == "2":
    import subprocess
    subprocess.run(["python", "face_recognizer/recognizer.py"])
elif choice == "3":
    import subprocess
    subprocess.run(["python", "face_recognizer/reset_all.py"])
elif choice == "4":
    import subprocess
    subprocess.run(["python", "face_recognizer_gui/face_gui.py"])
elif choice == "5":
    import subprocess
    subprocess.run(["python", "face_recognizer/free_scan_trainer.py"])
elif choice == "6":
    import subprocess
    subprocess.run(["python", "face_recognizer/rename_subject.py"])
else:
    print("Exiting.")
