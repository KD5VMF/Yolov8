import shutil
import os

confirm = input("This will DELETE all face data and encodings. Type YES to confirm: ").strip()
if confirm.upper() == "YES":
    if os.path.exists("faces"):
        shutil.rmtree("faces")
    if os.path.exists("encodings.pickle"):
        os.remove("encodings.pickle")
    print("All data wiped.")
else:
    print("Aborted.")
