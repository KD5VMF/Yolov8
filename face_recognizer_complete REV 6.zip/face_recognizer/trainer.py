import cv2
import os
import face_recognition
import pickle
import numpy as np

def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def is_blurry(image, threshold=100.0):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    fm = cv2.Laplacian(gray, cv2.CV_64F).var()
    return fm < threshold, fm

def collect_images(name, count=20, blur_threshold=100.0):
    ensure_dir(f"faces/{name}")
    cap = cv2.VideoCapture(0)
    saved = 0
    existing = len(os.listdir(f"faces/{name}"))

    print("Camera ready. Press 's' to start capturing images.")
    while True:
        ret, frame = cap.read()
        if not ret:
            continue
        cv2.imshow("Press 's' to start", frame)
        if cv2.waitKey(1) & 0xFF == ord('s'):
            break

    while saved < count:
        ret, frame = cap.read()
        if not ret:
            continue
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        boxes = face_recognition.face_locations(rgb)

        for box in boxes:
            top, right, bottom, left = box
            face_img = frame[top:bottom, left:right]
            blurry, score = is_blurry(face_img, threshold=blur_threshold)

            if blurry:
                print(f"Skipped blurry image (score={score:.2f})")
                continue

            save_path = f"faces/{name}/{existing + saved}.jpg"
            cv2.imwrite(save_path, face_img)
            saved += 1
            print(f"Saved {save_path} (sharpness={score:.2f})")
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, f"{name} [{saved}/{count}]", (left, top - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

        cv2.imshow("Training", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

def encode_faces():
    known_encodings = []
    known_names = []

    for name in os.listdir("faces"):
        folder = f"faces/{name}"
        if not os.path.isdir(folder):
            continue
        for file in os.listdir(folder):
            path = os.path.join(folder, file)
            image = face_recognition.load_image_file(path)
            encodings = face_recognition.face_encodings(image)
            if encodings:
                known_encodings.append(encodings[0])
                known_names.append(name)

    data = {"encodings": known_encodings, "names": known_names}
    with open("encodings.pickle", "wb") as f:
        pickle.dump(data, f)
    print("Encodings saved to encodings.pickle")

if __name__ == "__main__":
    existing_subjects = []
    if os.path.exists("faces"):
        existing_subjects = [d for d in os.listdir("faces") if os.path.isdir(os.path.join("faces", d))]

    print("Training Options:")
    for idx, subject in enumerate(existing_subjects):
        print(f"{idx + 1}: Continue training {subject}")
    print("N: Train a new subject")

    choice = input("Choose subject number or 'N': ").strip()

    if choice.lower() == 'n':
        person_name = input("Enter new subject's name: ").strip()
    else:
        try:
            index = int(choice) - 1
            person_name = existing_subjects[index]
        except (ValueError, IndexError):
            print("Invalid input. Exiting.")
            exit()

    try:
        count_input = input("How many images to capture? (1–2500, default 20): ").strip()
        count = int(count_input) if count_input else 20
        count = min(2500, max(1, count))
    except ValueError:
        count = 20

    print(f"Ready to train '{person_name}' with {count} sharp images.")
    print("A camera window will open. Press 's' to start capture, or 'q' to quit.")
    collect_images(person_name, count)
    encode_faces()
