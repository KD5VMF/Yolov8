import tkinter as tk
from tkinter import simpledialog, messagebox
import cv2
import face_recognition
import pickle
import os
import threading
import time

class FaceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Face Recognition Trainer & Recognizer")
        self.running = True
        self.mode = None
        self.name = ""
        self.capture_count = 20
        self.ready_to_start = False
        self.fps = 0
        self.capture = cv2.VideoCapture(0)

        # GUI elements
        self.label = tk.Label(root, text="Initializing...", font=("Arial", 14))
        self.label.pack()
        self.start_button = tk.Button(root, text="Start Training / Recognition", command=self.start_action, state=tk.DISABLED)
        self.start_button.pack(pady=10)
        self.switch_button = tk.Button(root, text="Switch Mode", command=self.switch_mode)
        self.switch_button.pack(pady=10)

        self.canvas = tk.Canvas(root, width=640, height=480)
        self.canvas.pack()

        self.frame = None
        self.encodings_file = "encodings.pickle"
        self.face_data_dir = "faces"
        os.makedirs(self.face_data_dir, exist_ok=True)
        self.data = {"encodings": [], "names": []}
        self.load_encodings()
        self.ask_mode()
        self.update_frame()

    def ask_mode(self):
        choice = messagebox.askquestion("Choose Mode", "Start in Training mode?
Click 'No' for Recognition mode.")
        self.mode = "train" if choice == 'yes' else "recognize"

        if self.mode == "train":
            self.prepare_training()
        else:
            self.label.config(text="Ready for face recognition. Press Start.")
        self.start_button.config(state=tk.NORMAL)

    def switch_mode(self):
        self.mode = "recognize" if self.mode == "train" else "train"
        if self.mode == "train":
            self.prepare_training()
        else:
            self.label.config(text="Ready for face recognition. Press Start.")
        self.start_button.config(state=tk.NORMAL)

    def prepare_training(self):
        self.name = simpledialog.askstring("Name", "Enter name for training:")
        if not self.name:
            messagebox.showerror("Error", "No name entered. Staying in previous mode.")
            self.mode = "recognize"
            return
        try:
            count_input = simpledialog.askstring("Images", "How many images to capture? (max 100, default 20):")
            self.capture_count = min(100, int(count_input)) if count_input else 20
        except ValueError:
            self.capture_count = 20
        self.label.config(text=f"Ready to train {self.name} with {self.capture_count} images.
Press Start when ready.")

    def start_action(self):
        self.start_button.config(state=tk.DISABLED)
        if self.mode == "train":
            threading.Thread(target=self.train_once, daemon=True).start()
        else:
            threading.Thread(target=self.recognize_loop, daemon=True).start()

    def update_frame(self):
        ret, frame = self.capture.read()
        if ret:
            self.frame = frame.copy()
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = cv2.resize(rgb, (640, 480))
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGBA)
            self.photo = tk.PhotoImage(master=self.canvas, data=cv2.imencode('.png', img)[1].tobytes())
            self.canvas.create_image(0, 0, anchor=tk.NW, image=self.photo)
        if self.running:
            self.root.after(30, self.update_frame)

    def train_once(self):
        person_dir = os.path.join(self.face_data_dir, self.name)
        os.makedirs(person_dir, exist_ok=True)
        existing_files = [f for f in os.listdir(person_dir) if f.lower().endswith(".jpg")]
        next_index = len(existing_files)
        saved = 0
        while saved < self.capture_count:
            ret, frame = self.capture.read()
            if not ret:
                continue
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            boxes = face_recognition.face_locations(rgb)
            for box in boxes:
                top, right, bottom, left = box
                face_img = rgb[top:bottom, left:right]
                save_path = os.path.join(person_dir, f"{next_index + saved}.jpg")
                cv2.imwrite(save_path, cv2.cvtColor(face_img, cv2.COLOR_RGB2BGR))
                saved += 1
                self.label.config(text=f"Saved {saved}/{self.capture_count} images for {self.name}")
                if saved >= self.capture_count:
                    break
        self.encode_faces()
        self.label.config(text="Training complete. Press Start to retrain or switch mode.")
        self.start_button.config(state=tk.NORMAL)

    def encode_faces(self):
        encodings = []
        names = []
        for person in os.listdir(self.face_data_dir):
            folder = os.path.join(self.face_data_dir, person)
            for file in os.listdir(folder):
                path = os.path.join(folder, file)
                image = face_recognition.load_image_file(path)
                enc = face_recognition.face_encodings(image)
                if enc:
                    encodings.append(enc[0])
                    names.append(person)
        self.data = {"encodings": encodings, "names": names}
        with open(self.encodings_file, "wb") as f:
            pickle.dump(self.data, f)
        self.label.config(text="Encodings saved.")

    def load_encodings(self):
        if os.path.exists(self.encodings_file):
            with open(self.encodings_file, "rb") as f:
                self.data = pickle.load(f)

    def recognize_loop(self):
        while True:
            ret, frame = self.capture.read()
            if not ret:
                continue
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            boxes = face_recognition.face_locations(rgb)
            encs = face_recognition.face_encodings(rgb, boxes)
            names = []
            for enc in encs:
                matches = face_recognition.compare_faces(self.data["encodings"], enc)
                name = "Unknown"
                if True in matches:
                    matched_ids = [i for i, b in enumerate(matches) if b]
                    counts = {}
                    for i in matched_ids:
                        counts[self.data["names"][i]] = counts.get(self.data["names"][i], 0) + 1
                    name = max(counts, key=counts.get)
                names.append(name)
            for (top, right, bottom, left), name in zip(boxes, names):
                cv2.rectangle(frame, (left, top), (right, bottom), (0,255,0), 2)
                cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX,
                            0.7, (255,255,255), 2)
            self.label.config(text=f"Recognized: {', '.join(names) if names else 'None'}")
            time.sleep(0.1)

    def on_close(self):
        self.running = False
        self.capture.release()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = FaceApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()
